<template>
  <div>
    <!-- <TimePicker></TimePicker> -->
    time
  </div>
</template>

<script>
// import TimePicker from '@/components/TimePicker.vue'
  export default {
    components:{
      // TimePicker
    },
  }
</script>

<style lang="less" scoped>

</style>